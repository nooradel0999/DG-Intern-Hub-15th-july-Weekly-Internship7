# LinkedIn Post Draft

Completed Week 7 — Web Application Testing with Burp Suite as part of DG Interns Hub. I practiced proxy interception, HTTPS certificate setup, Target mapping, Repeater validation, Intruder testing, and safe demonstrations of SQL injection, reflected XSS, IDOR/BOLA, weak authentication, and endpoint exposure — all inside a local intentionally vulnerable lab.

The key lesson was disciplined scope, redacted evidence, minimal-impact testing, and pairing every finding with remediation and retesting.

#CyberSecurity #VAPT #BurpSuite #WebApplicationSecurity #DGInternsHub