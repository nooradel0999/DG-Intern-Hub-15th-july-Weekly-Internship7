# Burp Suite Setup Checklist

- Install Burp Suite Community Edition.
- Set dedicated browser proxy to 127.0.0.1:8080.
- Visit http://burp and import the CA certificate into the lab profile.
- Scope only 127.0.0.1:8081.
- Capture login, map endpoints, use Repeater and a short rate-limited Intruder list.
- Use synthetic data and remove the temporary CA after testing.