# Week 7 VAPT Submission Pack

Candidate: Nooraleeman Adel Al-shawesh
Program: DG Interns Hub

Scope: local intentionally vulnerable training application only. Evidence is simulated training evidence, not an external engagement.